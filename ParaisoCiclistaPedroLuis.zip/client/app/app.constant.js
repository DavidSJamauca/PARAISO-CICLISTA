(function(angular, undefined) {
  angular.module("paraisoCiclistaApp.constants", [])

.constant("appConfig", {
	"userRoles": [
		"guest",
		"user",
		"admin"
	]
})

;
})(angular);