'use strict';

angular.module('paraisoCiclistaApp.util', []);
